package ru.casino.roulette.bets;

import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Ставка игрока. Ключ ставки — тип + набор чисел,
 * поэтому повторный клик по той же позиции увеличивает сумму.
 */
public class Bet {

    private final UUID player;
    private final String playerName;
    private final BetType type;
    private final Set<Integer> numbers;
    private long amount;

    public Bet(UUID player, String playerName, BetType type, Set<Integer> numbers, long amount) {
        this.player = player;
        this.playerName = playerName;
        this.type = type;
        this.numbers = new TreeSet<>(numbers);
        this.amount = amount;
    }

    public UUID getPlayer() {
        return player;
    }

    public String getPlayerName() {
        return playerName;
    }

    public BetType getType() {
        return type;
    }

    public Set<Integer> getNumbers() {
        return numbers;
    }

    public long getAmount() {
        return amount;
    }

    public void addAmount(long delta) {
        this.amount += delta;
    }

    /** Ключ для слияния ставок на одну позицию. */
    public String key() {
        return type.name() + ":" + numbers.stream().map(String::valueOf).collect(Collectors.joining(","));
    }

    /** Человекочитаемое описание, например "сплит 5-8" или "красное". */
    public String describe() {
        if (type == BetType.STRAIGHT) {
            return type.getLabel() + " " + numbers.iterator().next();
        }
        if (type == BetType.DOZEN || type == BetType.COLUMN) {
            return type.getLabel() + " " + numbers.iterator().next() + "-" + ((TreeSet<Integer>) numbers).last();
        }
        if (type == BetType.SPLIT || type == BetType.STREET || type == BetType.CORNER
                || type == BetType.SIXLINE) {
            return type.getLabel() + " " + numbers.stream().map(String::valueOf).collect(Collectors.joining("-"));
        }
        return type.getLabel();
    }
}
