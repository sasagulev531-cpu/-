package ru.casino.roulette;

import org.bukkit.plugin.java.JavaPlugin;
import ru.casino.roulette.balance.BalanceProvider;
import ru.casino.roulette.balance.FileBalanceProvider;
import ru.casino.roulette.commands.RouletteCommand;
import ru.casino.roulette.listeners.TableListener;
import ru.casino.roulette.table.TableManager;
import ru.casino.roulette.util.ChipManager;
import ru.casino.roulette.util.Messages;

/**
 * CasinoRoulette — европейская рулетка для Paper 1.21.x.
 *
 * Точка подключения своей валюты: поле balanceProvider ниже.
 * Реализуйте ru.casino.roulette.balance.BalanceProvider под свою экономику
 * (Vault, свой плагин и т.п.) и замените создание FileBalanceProvider.
 */
public class CasinoPlugin extends JavaPlugin {

    private static CasinoPlugin instance;

    private BalanceProvider balanceProvider;
    private TableManager tableManager;
    private ChipManager chipManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        Messages.init(this);
        this.chipManager = new ChipManager(this);
        // === ВАЛЮТА: пока тестовое хранилище в balances.yml ===
        this.balanceProvider = new FileBalanceProvider(this);
        this.tableManager = new TableManager(this);
        tableManager.load();
        getServer().getPluginManager().registerEvents(new TableListener(this), this);
        RouletteCommand executor = new RouletteCommand(this);
        var command = getCommand("roulette");
        if (command != null) {
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }
        getLogger().info("CasinoRoulette включён. Столов: " + tableManager.all().size());
    }

    @Override
    public void onDisable() {
        if (tableManager != null) {
            tableManager.shutdown();
        }
        if (balanceProvider != null) {
            balanceProvider.save();
        }
        instance = null;
    }

    public static CasinoPlugin get() {
        return instance;
    }

    public BalanceProvider getBalanceProvider() {
        return balanceProvider;
    }

    public TableManager getTableManager() {
        return tableManager;
    }

    public ChipManager getChipManager() {
        return chipManager;
    }
}
