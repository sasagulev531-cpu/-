package ru.casino.roulette.balance;

import java.util.UUID;

/**
 * Абстракция экономики.
 *
 * Чтобы подключить свою валюту (Vault, свой плагин и т.д.):
 *  1. Создайте класс, реализующий этот интерфейс.
 *  2. В CasinoPlugin#onEnable замените создание FileBalanceProvider на свой.
 *
 * Пока подключена тестовая реализация с хранением в balances.yml.
 */
public interface BalanceProvider {

    long getBalance(UUID player);

    /** Пополнить баланс. */
    void deposit(UUID player, long amount);

    /**
     * Списать средства.
     *
     * @return true — средства списаны; false — недостаточно средств, баланс не изменён
     */
    boolean withdraw(UUID player, long amount);

    /** Сохранить данные (вызывается при выключении сервера). */
    void save();
}
